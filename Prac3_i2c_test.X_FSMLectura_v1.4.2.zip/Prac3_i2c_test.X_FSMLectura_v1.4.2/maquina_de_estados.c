/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */

#include "maquina_de_estados.h"

// Convierte un dato entero sin signo a ASCII codificado en hexadecimal
void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char)
{
    uint8_t temp=0;
    // Guardando el caracter mas significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *b_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *b_char = temp;
    }
    dato_uint = dato_uint/16;

    // Guardando el caracter menos significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *a_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *a_char = temp;
    }
}

int FSM_ConvertirChar_2_decimal(char a, char b, char c, char d)
{
    int valor = 0;
    if((a >= '0') & (a <= '9'))
    {
        a = a - '0'; // tambien funciona con 48 en numero
        valor = 16*16*16*a;
    }
    if ((a >= 'A') & (a <= 'F'))
    {
        a = a - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*16*16*a);
    }

    if((b >= '0') & (b <= '9'))
    {
        b = b - '0'; // tambien funciona con 48 en numero
        valor = valor + (16*16*b);
    }
    if ((b >= 'A') & (b <= 'F'))
    {
        b = b - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*16*b);
    }

    if((c >= '0') & (c <= '9'))
    {
        c = c - '0'; // tambien funciona con 48 en numero
        valor = valor + (16*c);
    }
    if ((c >= 'A') & (c <= 'F'))
    {
        c = c - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*c);
    }

    if((d >= '0') & (d <= '9'))
    {
        d = d - '0'; // tambien funciona con 48 en numero
        valor = valor + (d);
    }
    if ((d >= 'A') & (d <= 'F'))
    {
        d = d - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (d);
    }
    return valor;

}


void FSM_Init_Estado(M_estados_T *m) 
{
    m->estado = ESTADO1;
    m->bandera_error = 0;
    m->bandera_inst1 = 0;
}
//HOY QUE AGREGAR AL HEADER DE MAQUINA DE ESATDOS
void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion)
{
    switch(m->estado)
    {     
        //======================================================================
        case ESTADO1:
            if(recepcion == 'R')
            {
                m->estado = ESTADO2;
                if(UART1_is_tx_ready())
                {
                    UART1_Write('1');
                }
            }

            if(recepcion == 'W')
            {
                m->estado = ESTADO3;
            }

            if ((recepcion != 'R')&&(recepcion != 'W'))
            {
              m->bandera_error = 1;
              m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO2:
            if(recepcion == 'B')
            {
                m->count = 0; // Inicializa el contador
                m->estado = ESTADO4;
                if(UART1_is_tx_ready())
                {
                    UART1_Write('2');
                }
            }

            if(recepcion == 'S')
            {
                m->count = 0; // Inicializa el contador
                m->count_aux = 0; // Inicializa el contador
                m->estado = ESTADO5;
                if(UART1_is_tx_ready())
                {
                    UART1_Write('2');
                }
            }

             if ((recepcion != 'B')&&(recepcion != 'S'))
            {
                //m->estado = ESTADO2; //si se recibe un dato diferente a 'B' o 'S' debe regresar al estado 1
                // tambien se deberia notificar del error ERR2 (error en estado 2)
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO3:
            if(recepcion == 'B')
            {
                m->estado = ESTADO6;
                if(UART1_is_tx_ready())
                {
                    UART1_Write('3');
                }
            }

            if(recepcion == 'S')
            {
                m->estado = ESTADO7;
                if(UART1_is_tx_ready())
                {
                    UART1_Write('3');
                }
            }
             if ((recepcion != 'B')&&(recepcion != 'S'))
            {
                //m->estado = ESTADO3;//si se recibe un dato diferente a 'B' o 'S' debe regresar al estado 1
                // tambien se deberia notificar del error ERR3 (error en estado 3)
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            // Se espera leer 4 datos
            // Si la direccion esta disponible se envian lo que hay en esa direccion
		 if(UART1_is_tx_ready())
            {
                UART1_Write(m->count+48); // Ver el dato en ASCII
            } 
         
            if (m->count < 3)
            {
                m->array_aux[m->count] = recepcion;
                
                if (m->count >= 2 && recepcion == '\n') // Evalua el ultimo dato de la instruccion
                {
                    m->bandera_inst1 = 1;	
                    m->estado = ESTADO1;      
                }
                
                if (m->count >= 2 && recepcion != '\n')
                {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }
                
                m->count = m->count+1; 
            } // termino de guardar los datos en el vector rxData
        break;

        /*
        //======================================================================
        case ESTADO5:
            // R|S|(address)|(num)|\n leo (num) datos desde la direccion (address)
            // R S x x , y y \n

            if (m->count < 7)
            {
                m->array_aux[m->count] = recepcion;
                if (m->count >= 2 && recepcion == ',')
                {
                    m->array_aux2[m->count_aux] = recepcion;

                    if(m->count_aux >= 2 && recepcion == '\n')
                    {
                        m->bandera_inst2 = 1;
                        m->estado = ESTADO1;
                    }
                    if(m->count_aux >= 1 && recepcion != '\n')
                    {
                        m->bandera_error = 1;
                        m->estado = ESTADO1;
                    }
                    
                    m->count_aux = m->count_aux+1;

                }
                if (m->count >= 2 && recepcion != ',')
                {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }

                m->count = m->count+1;

            } // termino de guardar los datos en el vector rxData

            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO2;
            }
        break;

            /*
        //======================================================================
        case ESTADO6: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]


            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO7:
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        default:
            m->estado = ESTADO1;
            // Aqu� nunca deberia llegar. Si llega por casualidad devuelve al
            // estado 1

            */

    } /*switch */
} /* FSM */