// Funciones generadas con MCC
#include "mcc_generated_files/mcc.h"
// Funciones propias de los autores
#include "maquina_de_estados.h"
#include "cola.h"

/*
                         Main application
 */

void main(void) {
    // Initialize the device
    SYSTEM_Initialize();
    
    // Banderas para los condicionales de Polling
    uint8_t bandera_leerMem = 0;
    uint8_t bandera_escribirMem = 0;
    
    // Serial UART1
    DATOCOLA rxData;
    //volatile uint8_t rxData;
    
    // I2C
    i2c1_address_t mem_address =  0x50; //direccion I2C de la memoria
    uint8_t lecturaMemoria;

    // FSM
    M_estados_T maquina;
    
    eCola_T recepcion; // La cola es del tipo First In, First Out
    eCola_T envio;
    
    FSM_Init_Estado(&maquina);
    
    // Cola
    /*
    DATOCOLA rxCola;
    char bandera_cola = 0x00; // Contiene dos banderas
    
    inicie_cola(&recepcion);
    inicie_cola(&envio);
	*/
	//Aux
    uint8_t direccion_inicial[2] = {0, 0}; // Direccion inicial que se va a leer EN la memoria
    uint8_t direccion[2] = {0, 0}; // Direccion inicial que se va a leer EN la memoria
    uint8_t n_direcciones = 0; // Para saber cuando espacios de memoria leer
    
    uint16_t direccion_final = 0; // Direccion final que se va a leer EN la memoria
    uint16_t direccion_2Bytes = 0; // Direccion final que se va a leer EN la memoria
    
    uint8_t dato_test = 72; // H en ASCII
    
    
    while(1) {       
        if(UART1_is_rx_ready()) {
            // Recepcion es el dato que se recibe en la UART.
            rxData = UART1_Read();
            FSM_maquina_de_estados(&maquina, rxData);
        }  
        
        if (maquina.bandera_inst1 == 1) {
            direccion[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]);
            direccion[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]);
            
            bandera_escribirMem = 1; // Luego de conocer la direccion, se activa una bandera para leer el dato
            
            // Vamos a escribir un dato en direccion antes de que lo lea. (Para probar)
            if(bandera_escribirMem == 1) {
                bandera_escribirMem = 0; // Reset de la bandera            
                i2c_write1ByteRegister(mem_address, &direccion[0], dato_test); // �Como debe entar el registro?                          
                DELAY_milliseconds(10); // Probar a�adiendo un delay de 100 ms // Aqu� iria el time-out de tantos milisegundos   
                bandera_leerMem = 1;
                /*escribir el dato en una pos en memoria i2c fija subir bandera de leer el dato de memoria*/ 
            }
            
            // <=0x7F FF
            if (direccion[0] <= 127 && bandera_leerMem == 1) {
                bandera_leerMem = 0;
                lecturaMemoria = i2c_read1ByteRegister(mem_address, &direccion[0]);
                if(UART1_is_tx_ready()) {
                    UART1_Write(direccion[0]);
                    UART1_Write(direccion[1]);
                    UART1_Write(lecturaMemoria);
                    UART1_Write('\n');
                }
            }
            maquina.bandera_inst1 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        }


        if (maquina.bandera_inst2 == 1) {            
            // Con direcciones sabemos desde que valor leer la memoria
            direccion_inicial[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]); // High
            direccion_inicial[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]); // Low
            
            // Con interaciones sabemos hasta que valor contar
            n_direcciones = FSM_Hex2Int(maquina.vec_numero[1],maquina.vec_numero[2]); // array[0]=','
            
            direccion_2Bytes = FSM_Vec2Short(maquina.vec_direccion[0], maquina.vec_direccion[1], maquina.vec_direccion[2], maquina.vec_direccion[3]);
            direccion_final = direccion_2Bytes + n_direcciones;
            
            // En caso de no funcionar, colocar castint (uint8_t)
            direccion[0] = (uint8_t)(direccion_final>>8); // Desplaza los MSB a la derecha para que ingresen en direccion[0] (1 Byte)
            direccion[1] = (uint8_t)direccion_final; // Obtiene los LSB 
            
            bandera_escribirMem = 1;
                       
            // Vamos a escribir un dato en direccion antes de que lo lea. (Para probar)
            if(bandera_escribirMem == 1) {
                bandera_escribirMem = 0; // Reset de la bandera
                
                // <=0x7F FF
                if(direccion_final >= 32767) {// direccion[0] >= 127) { //direccion_final >= 32767) {
                    maquina.bandera_error = 1;
                }
                
                
                while(direccion_2Bytes != direccion_final && maquina.bandera_error == 0) {
                    i2c_write1ByteRegister(mem_address, &direccion_inicial[0], dato_test); // �Como debe entar el registro?                          
                    DELAY_milliseconds(10); // Probar a�adiendo un delay de 100 ms // Aqu� iria el time-out de tantos milisegundos   
                    bandera_leerMem = 1;

                    if (bandera_leerMem == 1) {
                        bandera_leerMem = 0;
                        lecturaMemoria = i2c_read1ByteRegister(mem_address, &direccion_inicial[0]);
                        if(UART1_is_tx_ready()) {
                            UART1_Write('K');
                            UART1_Write(lecturaMemoria);
                        }
                    }
                    direccion_2Bytes = direccion_2Bytes + 1;
                    // Si el Low es igual o menor a su valor maximo, sumar 1
                    if(direccion_inicial[1] <= 255) {
                        direccion_inicial[1] = direccion_inicial[1] + 1; 
                    }
                    else {
                        direccion_inicial[0] = direccion_inicial[0] + 1; 
                        direccion_inicial[1] = 0;
                    }
                }
            }   
                /*escribir el dato en una pos en memoria i2c fija subir bandera de leer el dato de memoria*/            
            maquina.bandera_inst2 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        }
        
		
        if (maquina.bandera_error == 1) {
            // Reiniciar la bandera.
            maquina.bandera_error = 0;
            if(UART1_is_tx_ready()) {
                UART1_Write('-');
                UART1_Write('E');
                UART1_Write('R');
                UART1_Write('R');
                UART1_Write('\n');
            }
        }
    } /* while */
} /* main */
/**
 End of File
*/