/* Ruler 1         2         3         4         5         6         7        */
/******************************  main_v1.4.9.c  *******************************/
/*                                                                            */
/*   Proposito: Comunicaci�n serial entre el circuito y un computador. A su   */
/*              vez se utiliza de la comunicacion I2C entre el circuito y una */
/*              memoria.                                                      */
/*                                                                            */
/*  Programado usando sondeo o polling.                                       */
/*                                                                            */
/*   Origin:  Escrito y probado por                                           */
/*            Cristian-Ovidio  Duran-Celis                                    */
/*            Juan-Sebastian   Parrado-Gutierrez                              */
/*            Jeliza           Varon-Heredia                                  */
/*            Diciembre 7, 2020                                               */
/*                                                                            */
/*   e-mail:  cristianduran@javeriana.edu.co                                  */
/*                parrado-j@javeriana.edu.co                                  */
/*            jelitza.varon@javeriana.edu.co                                  */
/*                                                                            */
/*   Notas:                                                                   */
/*                                                                            */
/******************************************************************************/


/******************************************************************************/
/* ------------------------------- librerias -------------------------------- */
/******************************************************************************/
// Funciones generadas con MCC
#include "mcc_generated_files/mcc.h"
// Funciones propias de los autores
#include "maquina_de_estados.h"
#include "cola.h"


/******************************************************************************/
/*--------------------------------- main ------------------------------------ */
/******************************************************************************/
void main(void) {
    // Initialize the device
    SYSTEM_Initialize();
    
    // Banderas para los condicionales de Polling. Utilizados para la memoria
    bool bandera_leerMem = 0;
    bool bandera_escribirMem = 0;
    
    // Serial UART #1
    DATOCOLA rxData; // Aqui se guarda lo que llega del serial
    
    // I2C
    i2c1_address_t mem_address =  0x50; //direccion I2C de la memoria
    uint8_t lecturaMemoria; // Aqui se guarda lo que se lea en la memoria
    volatile char vec_lectura[2] = {0, 0};

    // Cola
    eCola_T recepcion; // La cola es del tipo First In, First Out
    inicie_cola(&recepcion);
    
    // FSM
    M_estados_T maquina;
      
    FSM_Init_Estado(&maquina);
    FSM_Init_Apuntadores(&maquina, &recepcion);
    
	// Variables auxiliares para la lectura y env�o de daots
    // Direccion inicial que se va a leer EN la memoria. Instrucciones RB y WB
    uint8_t direccion[2] = {0, 0}; 
    // Direccion inicial que se va a leer EN la memoria. Instrucciones RS y WS
    uint8_t direccion_inicial[2] = {0, 0}; 
    uint8_t n_direcciones = 0; // Para saber cuantos espacios de memoria leer
    uint16_t direccion_final = 0; // Direccion final que se va a leer EN la 
                                  // memoria
    uint16_t direccion_2Bytes = 0; // Direccion inicial de 16 bits que se va a
                                   // leer EN la memoria
    
    uint8_t valor = 0; // Lo que se escribe usando WB y WS
    uint8_t contador = 0; // Contador para leer los datos en la isntruccion WS
    
/******************************************************************************/
/*-------------------------------- while -------------------------------------*/
/******************************************************************************/ 
    while(1) {       
        if(UART1_is_rx_ready()) {
            // Recepcion es el dato que se recibe en la UART.
            rxData = UART1_Read();
            FSM_maquina_de_estados(&maquina, rxData);
        }  
        
        
/******************************************************************************/        
        // |R|B|(ADD)|\n|
/******************************************************************************/
        if (maquina.bandera_inst1 == 1) {
            
            direccion[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]);
            direccion[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]);
                       
            // direccion <=0x7F FF // Si es mayor a eso, hay error
            if(direccion[0] >= 127) {
                maquina.bandera_error = 1;
            }
            bandera_leerMem = 1;
            if (bandera_leerMem == 1 && maquina.bandera_error == 0) {
                bandera_leerMem = 0; // Reinicio de la bandera
                //bandera_escribirMem = 1; // Una vez leida la memoria, se puede 
                                         // escribir
                // LecturaMemoria es un dato ASCII entero sin signo que toca
                // convertir a un arreglo ASCII
                lecturaMemoria = i2c_read1ByteRegister(mem_address, &direccion[0]);
                FSM_Int2Hex(lecturaMemoria, &vec_lectura[0], &vec_lectura[1]);
                
                if(UART1_is_tx_ready()) {
                    UART1_Write(vec_lectura[0]);
                    UART1_Write(vec_lectura[1]);
                    UART1_Write('\n');
                }
            }
            maquina.bandera_inst1 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        } // if (maquina.bandera_inst1)
        
        
/******************************************************************************/
        // |R|S|(ADD)| , |(NUM)|\n|
/******************************************************************************/
        if (maquina.bandera_inst2 == 1) {            
            // Con direcciones sabemos desde que valor leer la memoria.
            // Se usa esta variable, pues es la que ingresa a la funcion de
            // lectura de memoria
            direccion_inicial[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]); // High
            direccion_inicial[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]); // Low
            
            // Con direccion_2Bytes sabemos desde que valor leer la memoria
            direccion_2Bytes = FSM_Vec2Short(maquina.vec_direccion[0], maquina.vec_direccion[1], maquina.vec_direccion[2], maquina.vec_direccion[3]);
            
            // Con interaciones sabemos hasta que valor contar
            n_direcciones = FSM_Hex2Int(maquina.vec_numero[1], maquina.vec_numero[2]); // array[0]=','
            
            direccion_final = direccion_2Bytes + n_direcciones;
            
            // Bandera para evitar que se reingrese al proceso de lectura y  
            // afecte en la lectura
            bandera_leerMem = 1; 
            if(bandera_leerMem == 1) {
                bandera_leerMem = 0; // Reset de la bandera
                
                // direccion <=0x7F FF // Si es mayor a eso, hay error
                if(direccion_final >= 32767) {// direccion[0] >= 127) {
                    maquina.bandera_error = 1;
                }
                while(direccion_2Bytes != direccion_final && maquina.bandera_error == 0) {
                    DELAY_milliseconds(10); // La lectura es tan rapida que es 
                                            // necesario esperar entre lecturas
                    lecturaMemoria = i2c_read1ByteRegister(mem_address, &direccion_inicial[0]);
                    FSM_Int2Hex(lecturaMemoria, &vec_lectura[0], &vec_lectura[1]);

                    //bandera_escribirMem = 1; // Una vez leido el dato, se puede
                                             // escribir en la memoria
                    //contador = 0;
                    if(UART1_is_tx_ready()) {
                        UART1_Write((uint8_t)direccion_inicial[0]);
                        UART1_Write(vec_lectura[0]);
                        UART1_Write(vec_lectura[1]);
                        UART1_Write('\n');
                    }
                    
                    // La direccion se actualiza una vez ha sido impresa
                    direccion_2Bytes = direccion_2Bytes + 1;
                    
                    // Si el Low es igual o menor a su valor maximo, sumar 1
                    if(direccion_inicial[1] <= 255) {
                        direccion_inicial[1] = direccion_inicial[1] + 1; 
                    }
                    else {
                        direccion_inicial[0] = direccion_inicial[0] + 1; 
                        direccion_inicial[1] = 0;
                    }
                } // while(direccion_inicial != direccion_final)
            } // if(bandera_leerMem)             
            maquina.bandera_inst2 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        } // if (maquina.bandera_inst2)
        
        
/******************************************************************************/        
		// |W|B|ADD| , |VAL|\n|
/******************************************************************************/
        if (maquina.bandera_inst3 == 1) {
            direccion[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]);
            direccion[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]);
            
            
            // Valor que se escribe. array[0]=','			
            valor = FSM_Hex2Int(maquina.vec_numero[1], maquina.vec_numero[2]);
            // Convierte de ASCCII en arreglo a un numero de 8 bits
            //valor = (uint8_t)((maquina.vec_numero[1]*16) + (maquina.vec_numero[2]));
           
            bandera_escribirMem = 1; // Luego de conocer la direccion, se activa una bandera para leer el dato
            
            // direccion <=0x7F FF // Si es mayor a eso, hay error
            if(direccion[0] >= 127) { 
                maquina.bandera_error = 1;
            }
            
            if(bandera_escribirMem == 1 && maquina.bandera_error == 0) {
                bandera_escribirMem = 0; // Reset de la bandera
                i2c_write1ByteRegister(mem_address, &direccion[0], valor);                        
                DELAY_milliseconds(10);
                
                //bandera_leerMem = 1; // Una vez se escribe en la memoria,
                                     // se puede leer
            }
            maquina.bandera_inst3 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        } // if (maquina.bandera_inst3)
         
        
        
/******************************************************************************/
        // |W|S|(ADD)| , |(NUM)| , |d0| , |d1| , | ... | , |dn|\n|
/******************************************************************************/       
        if (maquina.bandera_inst4 == 1) {
            direccion_inicial[0] = FSM_Hex2Int(maquina.vec_direccion[0], maquina.vec_direccion[1]);
            direccion_inicial[1] = FSM_Hex2Int(maquina.vec_direccion[2], maquina.vec_direccion[3]);
            
            // Con direccion_2Bytes sabemos desde que valor leer la memoria
            direccion_2Bytes = FSM_Vec2Short(maquina.vec_direccion[0], maquina.vec_direccion[1], maquina.vec_direccion[2], maquina.vec_direccion[3]);
            
            // Con interaciones sabemos hasta que valor contar
            n_direcciones = FSM_Hex2Int(maquina.vec_numero[1],maquina.vec_numero[2]); // array[0]=','
            
            direccion_final = direccion_2Bytes + n_direcciones;
            
            
            // direccion <=0x7F FF // Si es mayor a eso, hay error
            if(direccion_final >= 32767) { // direccion[0] >= 127) {
                maquina.bandera_error = 1;
            }
            
            contador = 3; // Desde aqui empieza a leer los valores que se van a guardar 
            
            
            while(direccion_2Bytes != direccion_final && maquina.bandera_error == 0) {
                // Valor que se escribe. array[0]=','
                DELAY_milliseconds(10); 
                valor = FSM_Hex2Int(maquina.vec_numero[contador], maquina.vec_numero[contador+1]);
                //valor = (uint8_t)((maquina.vec_numero[contador+1]*16) + (maquina.vec_numero[contador]));
                
                bandera_escribirMem = 1;
                if (bandera_escribirMem == 1) {
                    bandera_escribirMem = 0;
                    i2c_write1ByteRegister(mem_address, &direccion_inicial[0], valor);  
                    DELAY_milliseconds(10); 
                } 
                
                if(UART1_is_tx_ready()) {
                    UART1_Write('O');
                    UART1_Write('K');
                    UART1_Write('\n');
                }
                
                // La direccion se actualiza una vez ha sido impresa
                direccion_2Bytes = direccion_2Bytes + 1;
                contador = contador + 1;
                // Si el Low es igual o menor a su valor maximo, sumar 1
                if(direccion_inicial[1] <= 255) {
                    direccion_inicial[1] = direccion_inicial[1] + 1; 
                }
                else {
                    direccion_inicial[0] = direccion_inicial[0] + 1; 
                    direccion_inicial[1] = 0;
                } 
            } // while(direccion_inicial != direccion_final)
            
            //bandera_leerMem = 1; // Una vez se escribe en la memoria,
                                 // se puede leer
            
            /*
            if(UART1_is_tx_ready()) {
                UART1_Write(valor);
                //UART1_Write('O');
                //UART1_Write('K');
                UART1_Write('\n');
            }
            */
        maquina.bandera_inst4 = 0; // Reinicia la bandera cuando ya ha escribe un dato
        } // if (maquina.bandera_inst4)

        
/******************************************************************************/          
        // |E|R|R|\n|
/******************************************************************************/  
        if (maquina.bandera_error == 1) {
            maquina.bandera_error = 0; // Reinicio de la bandera
            if(UART1_is_tx_ready()) {
                UART1_Write('E');
                UART1_Write('R');
                UART1_Write('R');
                UART1_Write('\n');
            }
        } // if (maquina.bandera_error)
    } /* while */
} /* main */