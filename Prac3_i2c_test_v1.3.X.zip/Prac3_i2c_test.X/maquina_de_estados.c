/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */ 

#include "maquina_de_estados.h"

// Convierte un dato entero sin signo a ASCII codificado en hexadecimal 
void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char)
{
    uint8_t temp=0;
    // Guardando el caracter mas significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *b_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *b_char = temp;
    }
    dato_uint = dato_uint/16;

    // Guardando el caracter menos significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *a_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *a_char = temp;
    }
}


void FSM_Init_Estado(M_estados_T *m) //, eCola_T *a)
{
    //state_T states;
    //states = ESTADO1;
    m->estado = ESTADO1;
    //  m->ptr = *a;
}

void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion) //unsigned char recepcion)
{
    //state_T states; // Contiene la numeracion de los estados desde cero.
    char rxData[4]; // Lo que retorna cola_add
    char rxData_aux[2]; // Arreglo donde se guarda el valor de cuantas direcciones se van a leer
    volatile int count_aux = 0;
    volatile int count = 0;
    DATOCOLA last_dato; // Para guardar fin de linea
    char bandera_exito = 0;
    char bandera_error = 0;
    
    char dato_error;
    //char address[2] = {0x00, 0x00}; // Direccion de 16 bits/2 Bytes
    //uint8_t Byte; // High Byte y Low Byte
    
    switch(m->estado)
    {
        /* // Esto va en el main
        case ESTADO0
        if(!recepcion_serial) // Si no hay recepcion
        {
            m->estado = ESTADO0;
        }
        else // Si hay recepcion
        {
            m->estado = ESTADO1;
        }
        break;
        */

        //======================================================================
        case ESTADO1:
            if(recepcion == 'R')
            {
                m->estado = ESTADO2;
            }

            if(recepcion == 'W')
            {
                m->estado = ESTADO3;
            }

            if(recepcion == 'E')
            {
               m->estado = ESTADO8;
            }
            else
            {
                dato_error = 'E';
                UART1_Write('R');
                UART1_Write('R'); 
                UART1_Write('\n'); 
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO2:
            if(recepcion == 'B')
            {
                m->estado = ESTADO4;
            }

            if(recepcion == 'S')
            {
                m->estado = ESTADO5;	
            }

            else
            {
                m->estado = ESTADO2;
            }
        break;

        //======================================================================
        case ESTADO3:
            if(recepcion == 'B')
            {
                m->estado = ESTADO6;
            }	

            if(recepcion == 'S')
            {
                m->estado = ESTADO7;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;

        //======================================================================
        case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            // Se espera leer 4 datos
            
            if (count < 5)
            {
                rxData[count] = recepcion; // Guardando la direccion de 16 bits
                
                if (count >= 4 && recepcion == '\n') // Evalua el ultimo dato de la instruccion
                {
                    last_dato = recepcion;
                    bandera_exito = 1;
                    m->estado = ESTADO1;
                }
                if (count >= 4 && recepcion != '\n')
                {
                    bandera_error = 1;
                    dato_error = "ERR\n";
                    UART1_Write(dato_error);                    
                    m->estado = ESTADO1;
                }
                
                count = count+1;
                
            } // termino de guardar los datos en el vector rxData
            
            if(bandera_exito == 1)
            {
                //escriba en uart los datos del vector rxData
                //esto es con funciones de UART               
                UART1_Write(rxData); 
                m->estado = ESTADO1;//Pasamos de estado
            }            
        break;
        
        /*

        //======================================================================
        case ESTADO5:
        // R|S|(address)|(num)|\n leo (num) datos desde la direcci�n (address)
        // R S x x x x , y y \n
            volatile int count = 0;
            
            if (count < 5)
            {
                rxData[count] = recepcion; // Guardando la direccion de 16 bits
                if (count >= 4 && recepcion == ',') // Evalua el ultimo dato de la instruccion
                {
                    volatile int count_aux = 0;
                    rxData_aux[count_aux] = recepcion;
                    
                    if(count_aux >= 1 && recepcion == '\n')
                    {
                        
                        m->estado = ESTADO1;
                    }
                    if(count_aux >= 1 && recepcion != '\n')
                    {
                        
                    }
                    
                    last_dato = recepcion;
                    bandera_exito = 1;
                    m->estado = ESTADO1;
                }
                if (count >= 4 && recepcion != ',')
                {
                    bandera_error = 1;
                    dato_error = "ERR\n";
                    UART1_Write(dato_error);                    
                    m->estado = ESTADO1;
                }
                
                count = count+1;
                
            } // termino de guardar los datos en el vector rxData
            
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO2;
            }
        break;


        //======================================================================
        case ESTADO6: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            
            
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO7:
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO8:
            // No se que hace cuando recibe una E en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;

        default:
            m->estado = ESTADO1;
            // Aqu� nunca deberia llegar. Si llega por casualidad devuelve al 
            // estado 1
            
            */
            
    } /*switch */	
} /* FSM */
