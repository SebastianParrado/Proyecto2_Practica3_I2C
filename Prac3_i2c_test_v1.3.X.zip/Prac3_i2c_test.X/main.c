/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.6
        Device            :  PIC18F47K42
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
// Funciones propias de los autores
#include "maquina_de_estados.h"
#include "cola.h"

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    // Banderas para los condicionales de Polling
    uint8_t bandera_leerMem = 0;
    uint8_t bandera_escribirMem = 0;
    uint8_t bandera_escribirUART = 0;
    uint8_t bandera_escribirUART2 = 0;
    
    // Serial UART1
    volatile uint8_t rxData;
    
    volatile uint8_t rxPrueba;
    // I2C
    i2c1_address_t rand_address =  0x50;
    uint8_t registro[2] = {0x00, 0xFF};
    char lecturaMemoria;

    // FSM
    M_estados_T maquina;
    FSM_Init_Estado(&maquina);
    
    // Cola
    char bandera_cola = 0x00; // Contiene dos banderas
    #define ERROR 0x01 // Si hay error, es mas facil evaluar un 1
    #define BIEN  0x00
    #define HUBO_FINLINEA   0x02;
    #define NO_HUBOFINLINEA 0x03;
    /* Tabla de verdad
     * 0 | 0 || BIEN GUARDADO EL DATO
     * 0 | 1 || ERROR GUARDANDO EL DATO
     * 1 | 0 || HAY FIN DE LINEA
     * 1 | 1 || NO HAY FIN DE LINEA
     */
    eCola_T fifo; // La cola es del tipo First In, First Out
    inicie_cola(&fifo);
    
    while(1)
    {
        // Logic to echo received data
        /* // <-- UART 
        if(UART1_is_rx_ready())
        {
            rxData = UART1_Read();
            if(UART1_is_tx_ready())
            {
                UART1_Write(rxData);
            }
            DELAY_milliseconds(1000);
        }
        */ // <-- Fin UART

        /*lea un dato por el serial*/
        if(UART1_is_rx_ready())
        {
            // Recepcion es el dato que se recibe en la UART.
            rxData = UART1_Read();
           
            // Luego de leer el caracter de 8 bits, se guarda en la cola.
            // Si se guarda bien el dato, retorna un 0. Si NO se guarda bien el 
            // dato, retorna un 1
            bandera_cola = cola_add(&fifo, rxData); // Agregar un dato que retorne
            
            rxPrueba = cola_get(&fifo);
            
            FSM_maquina_de_estados(&maquina, rxPrueba);
            
            // alguna bandera cuando halla un fin de linea
            
            bandera_escribirMem = 1;
            
             /*lea el dato y guardelo y suba la bandera de guardar este dato en memoria*/
        }
        
        

    } /* while */
} /* main */
/**
 End of File
*/