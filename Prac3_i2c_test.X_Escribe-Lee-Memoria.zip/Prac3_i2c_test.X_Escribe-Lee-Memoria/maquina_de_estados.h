/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef FSM_H
#define	FSM_H

#include <xc.h> // include processor files - each processor file is guarded.  

#include <stdio.h>
#include "mcc_generated_files/uart1.h"
#include "cola.h"

// Numeracion de estados
/*
typedef enum state_T state_T;
enum state_T
{
    ESTADO0, ESTADO1, ESTADO2, ESTADO3, ESTADO4, ESTADO5, ESTADO6, ESTADO7, ESTADO8
};
*/
//#define ESTADO0 0
#define ESTADO1 1
#define ESTADO2 2
#define ESTADO3 3
#define ESTADO4 4
#define ESTADO5 5
#define ESTADO6 6
#define ESTADO7 7
#define ESTADO8 8
//
int count = 0, bandera_exito = 0;
DATOCOLA rxData[4], last_dato;


// Estructura para la maquina de estados
typedef struct M_estados_T M_estados_T;
struct M_estados_T
{
    int8_t estado;
    // Banderas para polling
	char array_aux[4];
    char bandera_error;
    char bandera_inst1;
    char envie_error;	
    //eCola_T *ptr;
};

void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char);

uint8_t FSM_Char2Int(char a, char b, char c, char d);

void FSM_Init_Estado(M_estados_T *m);

void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion); // Antes era un char

#endif	/* FSM_H */

