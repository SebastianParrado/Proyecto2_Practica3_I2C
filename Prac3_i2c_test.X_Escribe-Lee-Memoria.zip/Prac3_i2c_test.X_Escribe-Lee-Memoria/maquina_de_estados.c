/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */

#include "maquina_de_estados.h"

// Convierte un dato entero sin signo a ASCII codificado en hexadecimal
void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char)
{
    uint8_t temp=0;
    // Guardando el caracter mas significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *b_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *b_char = temp;
    }
    dato_uint = dato_uint/16;

    // Guardando el caracter menos significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *a_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *a_char = temp;
    }
}

uint8_t FSM_Char2Int(char a, char b, char c, char d)
	{
		uint8_t valor = 0;
		if((a >= '0') && (a <= '9'))
		{
			a = a - '0'; // tambien funciona con 48 en numero
			valor = 16*16*16*a;
		}
		if ((a >= 'A') && (a <= 'F'))
		{
			a = a - '7'; // a = a - 55
			// Si a = caracter A, entonces esta operacion entrega un 10
			valor = valor + (16*16*16*a);
		}	
		
		if((b >= '0') && (b <= '9'))
		{
			b = b - '0'; // tambien funciona con 48 en numero
			valor = valor + (16*16*b);
		}
		if ((b >= 'A') && (b <= 'F'))
		{
			b = b - '7'; // a = a - 55
			// Si a = caracter A, entonces esta operacion entrega un 10
			valor = valor + (16*16*b);
		} 
		
		if((c >= '0') && (c <= '9'))
		{
			c = c - '0'; // tambien funciona con 48 en numero
			valor = valor + (16*16*b);
		}
		if ((c >= 'A') && (c <= 'F'))
		{
			c = c - '7'; // a = a - 55
			// Si a = caracter A, entonces esta operacion entrega un 10
			valor = valor + (16*c);
		}

		if((d >= '0') && (d <= '9'))
		{
			d = d - '0'; // tambien funciona con 48 en numero
			valor = valor + (d);
		}
		if ((d >= 'A') && (d <= 'F'))
		{
			d = d - '7'; // a = a - 55
			// Si a = caracter A, entonces esta operacion entrega un 10
			valor = valor + (d);
		}  		
		
	}

void FSM_Init_Estado(M_estados_T *m) //, eCola_T *a)
{
    //state_T states;
    //states = ESTADO1;
    m->estado = ESTADO1;
	m->bandera_error = 0;
	m->bandera_inst1 = 0;
    //  m->ptr = *a;
}
                                                                            //HOY QUE AGREGAR AL HEADER DE MAQUINA DE ESATDOS

void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion) //unsigned char recepcion)
{

    switch(m->estado)
    {     
        //======================================================================
        case ESTADO1:
            if(recepcion == 'R')
            {
                m->estado = ESTADO2;
            }

            if(recepcion == 'W')
            {
                m->estado = ESTADO3;
            }

            if(recepcion == 'E')
            {
               m->estado = ESTADO8;
            }
            if ((recepcion != 'R')&&(recepcion != 'W')&&(recepcion != 'E'))
            {
              m->bandera_error = 1;
              m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO2:
            if(recepcion == 'B')
            {
                m->estado = ESTADO4;
            }

            if(recepcion == 'S')
            {
                m->estado = ESTADO5;
            }

             if ((recepcion != 'B')&&(recepcion != 'S'))
            {
                //m->estado = ESTADO2; //si se recibe un dato diferente a 'B' o 'S' debe regresar al estado 1
                // tambien se deberia notificar del error ERR2 (error en estado 2)
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO3:
            if(recepcion == 'B')
            {
                m->estado = ESTADO6;
            }

            if(recepcion == 'S')
            {
                m->estado = ESTADO7;
            }
             if ((recepcion != 'B')&&(recepcion != 'E'))
            {
                //m->estado = ESTADO3;//si se recibe un dato diferente a 'B' o 'S' debe regresar al estado 1
                // tambien se deberia notificar del error ERR3 (error en estado 3)
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            // Se espera leer 4 datos
            // Si la dirección está disponible se envian lo que hay en esa dirección
			
            if (count < 5)
            {
				m->array_aux[count] = recepcion;
                rxData[count] = recepcion; // Guardando la direccion de 16 bits

                // revisar si los condicionales de los if funcionan tambien
                // revisar si enviar un (10) se identifica como fin de linea ALTA IMPORTANCIA
                if (count >= 4 && recepcion == '\n') // Evalua el ultimo dato de la instruccion
                {
                    last_dato = recepcion;
                    bandera_exito = 1;
                    //m->estado = ESTADO1; todavia no se puede saltar de estado ya que no se completó la instrucción
                }
                if (count >= 4 && recepcion != '\n')
                {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }

                count = count+1;

            } // termino de guardar los datos en el vector rxData

            if(bandera_exito == 1)
            {				
                //escriba en uart los datos del vector rxData
                m->bandera_inst1 = 1;	
                m->estado = ESTADO1;
            }
        break;

        /*

        //======================================================================
        case ESTADO5:
        // R|S|(address)|(num)|\n leo (num) datos desde la direcci�n (address)
        // R S x x x x , y y \n
            volatile int count = 0;

            if (count < 5)
            {
                rxData[count] = recepcion; // Guardando la direccion de 16 bits
                if (count >= 4 && recepcion == ',') // Evalua el ultimo dato de la instruccion
                {
                    volatile int count_aux = 0;
                    rxData_aux[count_aux] = recepcion;

                    if(count_aux >= 1 && recepcion == '\n')
                    {

                        m->estado = ESTADO1;
                    }
                    if(count_aux >= 1 && recepcion != '\n')
                    {

                    }

                    last_dato = recepcion;
                    bandera_exito = 1;
                    m->estado = ESTADO1;
                }
                if (count >= 4 && recepcion != ',')
                {
                    bandera_error = 1;
                    dato_error = "ERR\n";
                    UART1_Write(dato_error);
                    m->estado = ESTADO1;
                }

                count = count+1;

            } // termino de guardar los datos en el vector rxData

            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO2;
            }
        break;


        //======================================================================
        case ESTADO6: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]


            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO7:
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO8:
            // No se que hace cuando recibe una E en el segundo espacio
            if(recepcion == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;

        default:
            m->estado = ESTADO1;
            // Aqu� nunca deberia llegar. Si llega por casualidad devuelve al
            // estado 1

            */

    } /*switch */
} /* FSM */
