/*
 * cola.c
 *
 * Created: 15/10/2020 6:18:33 p. m.
 *  Author: sebas
 */ 

#include "cola.h"

// La entrada, la salida y el peso inicializan en cero (0)
void inicie_cola(eCola_T *c)
{
	c->entrada = 0;
	c->salida  = 0;
	c->peso	   = 0;
} /* inicie_cola */

// Agrega datos en la cola
char cola_add(eCola_T *c, DATOCOLA dato)
{	
	if(!cola_llena(c)) // Si la cola no esta llena
	{
		c->data[c->entrada] = dato; // El dato de entrada se guarda en la cola. 
                                    // Se guarda en la posicion entrada
		c->peso    = c->peso+1;     // c->peso++;
		c->entrada = c->entrada+1;  // c->entrada++;
	}
	else
	{
		return ERROR;
	} /* endif */
	// Si llega hasta aca, es porque la cola aun no esta llena
	// y pide meter el dato en la cola
    
    // El siguiente condicional evalua si hubo fin de linea | \n |
    if(cola_FinLinea(dato))
    {
        return HUBO_FINLINEA;
    }
    else
    {
        return NO_HUBOFINLINEA;
    }
    
	if(c->entrada >= TAM)
	{
         c->entrada = 0;
	} /* endif */
	return BIEN;
} /* cola_add */ 

// Saca datos de la cola
DATOCOLA cola_get(eCola_T *c)
{	
	DATOCOLA temp;
	if(!cola_vacia(c)) // Si la cola no esta llena
	{
		temp = c->data[c->salida];
		// El dato de entrada se guarda en la cola. Se guarda en la posicion entrada
		c->peso    = c->peso-1; // c->peso--;
		c->salida = c->salida+1; // c->salida++;
	}
	else
	{
		return ERROR;
	} /* endif */
	// Si llega hasta aca, es porque la cola aun no esta llena
	// y pide meter el dato en la cola
	if(c->salida >= TAM)
	{
		c->salida = 0;
	} /* endif */
	return temp;
} /* cola_get */

// Retorna el valor que indica la cantidad de datos en al cola
int tam_cola(eCola_T *c)
{
	return (c->peso);
} /* tam_cola */

// Evalua si la cola esta llena
int cola_llena(eCola_T *c)
{
	if(c->peso>=TAM)
	{
		return SI;
	}
	else
	{
		return NO;
	} /* endif */
} /* cola_llena */

// Evalua si la cola esta vacia
int cola_vacia(eCola_T *c)
{
	if(c->peso<=0)
	{
		return SI;
	}
	else
	{
		return NO;
	} /* endif */
} /* cola_vacia */

// Observar si hay fin de linea
unsigned char cola_FinLinea(DATOCOLA dato)
{
    if(dato == '\n')
    {
        return SI;
    }
    else
    {
        return NO;
    }
}