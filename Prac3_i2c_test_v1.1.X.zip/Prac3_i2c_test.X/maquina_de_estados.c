/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */ 

#include "maquina_de_estados.h"

void FSM_Init_Estado(M_estados_T *m)
{
    STATE_T states;
    states = ESTADO1;
    m->estado = states;
}

char FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion) //unsigned char recepcion)
{
      STATE_T states; // Contiene la numeracion de los estados desde cero.
	// recepcion = 0x X X Y Y \n 
	
	switch(m->estado)
    {
      /* // Esto va en el main
	case ESTADO0
		if(!recepcion_serial) // Si no hay recepcion
		{
			m->estado = ESTADO0;
		}
		else // Si hay recepcion
		{
			m->estado = ESTADO1;
		}
	break;
	*/

	//==========================================================================
      case ESTADO1:
		if(recepcion == 'R')
		{
                UART1_Write(1); // Para porbar que llega aca
			m->estado = ESTADO2;
		}
		
		if(recepcion == 'W')
		{
                UART1_Write(2); // Para porbar que llega aca
			m->estado = ESTADO3;
		}
		
		if(recepcion == 'E')
		{
                UART1_Write(3); // Para porbar que llega aca
			m->estado = ESTADO8;
		}
		else
		{
			m->estado = ESTADO1;
		}
	break;
	
	//==========================================================================
	case ESTADO2:
		if(recepcion == 'B')
		{
			m->estado = ESTADO4;
		}
		
		if(recepcion = 'S')
		{
			m->estado = ESTADO5;	
		}
		
		else
		{
			m->estado = ESTADO2;
		}
	break;
	
	//==========================================================================
	case ESTADO3:
		if(recepcion = 'B')
		{
			m->estado = ESTADO6;
		}	
		
		if(recepcion = 'S')
		{
			m->estado = ESTADO7;
		}
		else
		{
			m->estado = ESTADO3;
		}
	break;
	
	//==========================================================================
	case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
		         // Suponiendo que UART_read pase de ASCII a entero.
		// La direccion es 0xYY
		//address = R(8 bits) B(8 bits) ADD(16 bits)
		UART1_Write(0);
           m->estado = ESTADO1;
            
            /*
		if(last_recepcion = '\n') // ver si se cambia por algo como Hubo_FinLinea(&recepcion)
		{
			m->estado = ESTADO1;
		}
		else
		{
			m->estado = ESTADO2;
		}
        
        */
	break;
	
	//==========================================================================
	case ESTADO5:
            /*
		if(last_recepcion = '\n')
		{
			m->estado = ESTADO1;
		}
		else
		{
			m->estado = ESTADO2;
		}
         */
	break;
	
	
	//==========================================================================
	case ESTADO6:
		if(last_recepcion = '\n')
		{
			m->estado = ESTADO1;
		}
		else
		{
			m->estado = ESTADO3;
		}
	break;
	
	
	//==========================================================================
	case ESTADO7:
		if(last_recepcion = '\n')
		{
			m->estado = ESTADO1;
		}
		else
		{
			m->estado = ESTADO3;
		}
		break;
	break;
	
	
	//==========================================================================
	case ESTADO8:
		if(last_recepcion = '\n')
		{
			m->estado = ESTADO1;
		}
		else
		{
			m->estado = ESTADO3;
		}
		break;
	break;
	
	default:
		m->estado = ESTADO1;
		// Aqu� nunca deberia llegar. Si llega por casualidad
    }	
}
