/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */ 


/* UN APUNTE SOBRE LA FSM. CREO QUE SE PUEDE REDUCIR UN POCO LOS ESTADOS
 * Creo que se deber�a agregar un estado unicamente dedicado a leer la direccion
 * Considero que al ingresar de una vez la cola con los datos, no hay mucha 
 * necesidad de hacer esto linealmente. Sabemos que los dos primeros caracteres 
 * son de 8 bits cada uno (Los caracteres son | R/W | B/S |). el tercer y cuarto
 * caracter son la direccion de 16 bits. Finalmente, queda el salto de linea, del
 * cual desconozco si se guarda en la cola o podemos prescindir de el.
 */
#include "maquina_de_estados.h"

void FSM_Init_Estado(M_estados_T *m)
{
    STATE_T states;
    states = ESTADO1;
    m->estado = states;
}

void FSM_maquina_de_estados(M_estados_T *m, eCola_T *recepcion) //unsigned char recepcion)
{
    STATE_T states; // Contiene la numeracion de los estados desde cero.
    char address[2] = {0x00, 0x00}; // Direccion de 16 bits/2 Bytes
    uint8_t Byte; // High Byte y Low Byte
    
    switch(m->estado)
    {
        /* // Esto va en el main
        case ESTADO0
        if(!recepcion_serial) // Si no hay recepcion
        {
            m->estado = ESTADO0;
        }
        else // Si hay recepcion
        {
            m->estado = ESTADO1;
        }
        break;
        */

        //======================================================================
        case ESTADO1:
            if(recepcion[0] == 'R')
            {
                //UART1_Write(1); // Para porbar que llega aca
                m->estado = ESTADO2;
            }

            if(recepcion[0] == 'W')
            {
                //UART1_Write(2); // Para porbar que llega aca
                m->estado = ESTADO3;
            }

            if(recepcion[0] == 'E')
            {
                //UART1_Write(3); // Para porbar que llega aca
               m->estado = ESTADO8;
            }
            else
            {
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO2:
            if(recepcion[1] == 'B')
            {
                m->estado = ESTADO4;
            }

            if(recepcion[1] == 'S')
            {
                m->estado = ESTADO5;	
            }

            else
            {
                m->estado = ESTADO2;
            }
        break;

        //======================================================================
        case ESTADO3:
            if(recepcion[1] == 'B')
            {
                m->estado = ESTADO6;
            }	

            if(recepcion[1] == 'S')
            {
                m->estado = ESTADO7;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;

        //======================================================================
        case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            address[Byte] = recepcion[Byte+2];
            address[Byte+1] = recepcion[Byte+3];
            // Ver como cambiar las dos lineas anteriores
            
            if(recepcion[4] == '\n') // ver si se cambia por algo como Hubo_FinLinea(&recepcion)
            {
               m->estado = ESTADO1;
            }
            else
            {
               m->estado = ESTADO2;
            }
        break;

        //======================================================================
        case ESTADO5:
        
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion[4] == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO2;
            }
        break;


        //======================================================================
        case ESTADO6: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            address[Byte] = recepcion[Byte+2];
            address[Byte+1] = recepcion[Byte+3];
            // Ver como cambiar las dos lineas anteriores
            
            if(recepcion[4] == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO7:
            // No se que hace cuando recibe una S en el segundo espacio
            if(recepcion[4] == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;


        //======================================================================
        case ESTADO8:
            // No se que hace cuando recibe una E en el segundo espacio
            if(recepcion[4] == '\n')
            {
                m->estado = ESTADO1;
            }
            else
            {
                m->estado = ESTADO3;
            }
        break;

        default:
            m->estado = ESTADO1;
            // Aqu� nunca deberia llegar. Si llega por casualidad devuelve al 
            // estado 1
    } /*switch */	
} /* FSM */
