/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef COLA_H
#define	COLA_H

#include <xc.h> // include processor files - each processor file is guarded.  

#include <stdio.h>
/*
 * cola.h
 *
 * Created: 15/10/2020 6:18:46 p. m.
 *  Author: sebas
 */

#define TAM  15 // Tamano maximo

#define ERROR 0x01 // Si hay error, es mas facil evaluar un 1
#define BIEN  0x00

#define HUBO_FINLINEA   0x02
#define NO_HUBOFINLINEA 0x03

#define SI 1
#define NO 0

typedef unsigned char DATOCOLA;
typedef struct eCola_T 
{
	DATOCOLA data[TAM];
	int entrada; // Posicion de entrada en el arreglo
	int salida; // Posicion de salida en el arreglo
	int peso; // Datos en la cola
} eCola_T;

void inicie_cola(eCola_T *c);
char cola_add(eCola_T *c, DATOCOLA dato);
DATOCOLA cola_get(eCola_T *c);
int tam_cola(eCola_T *c);
int cola_llena(eCola_T *c);
int cola_vacia(eCola_T *c);

unsigned char cola_FinLinea(DATOCOLA dato);

#endif	/* COLA_H */

