
#include "giroscopio.h"
    i2c1_address_t giro_address =  0x68; //direccion I2C del giroscopio
    uint8_t lecturaMemoria;
        
    // Giroscopio
    uint8_t reg_zero = 0x00;
    uint8_t config_giro_reg = 0x1B;
    uint8_t giro_power_mang = 0x6B;

void giro_init(i2c1_address_t giro_address, uint8_t giro_power_mang, uint8_t reg_zero){
    i2c_write1ByteRegMod(giro_address, giro_power_mang, reg_zero);
    i2c_write1ByteRegMod(giro_address, config_giro_reg, reg_zero);
}