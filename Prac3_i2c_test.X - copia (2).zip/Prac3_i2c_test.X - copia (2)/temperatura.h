/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef TEMPERATURA_H
#define	TEMPERATURA_H

#include <xc.h> // include processor files - each processor file is guarded.  

#include <stdio.h>
#include "mcc_generated_files/uart1.h"
#include "mcc_generated_files/delay.h"



typedef unsigned char TEMP_REGISTRO;
// Estructura para el sensor de temperatura
typedef struct temperatura_T temperatura_T;
struct temperatura_T
{
    TEMP_REGISTRO apuntador;
    TEMP_REGISTRO configuracion;
};

void temp_initRegApuntador(temperatura_T *ptr);
void temp_initConfig(temperatura_T *ptr);
void temp_initLectura(temperatura_T *ptr);



#endif	/* XC_HEADER_TEMPLATE_H */

